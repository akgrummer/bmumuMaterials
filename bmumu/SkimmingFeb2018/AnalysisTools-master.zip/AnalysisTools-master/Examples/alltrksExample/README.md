### Description

*src/alltrksExample.cpp:* This macro shows you how to use the all track information stored in the 
special flat and _skimmed_ ntuples.

In order to run it do:

`#You need to adjust path to the input file`

`make`

`bin/alltrksExample`
