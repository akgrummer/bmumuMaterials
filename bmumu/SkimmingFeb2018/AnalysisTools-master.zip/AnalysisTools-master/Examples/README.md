###Description
This directory contains subdirectories with scripts/macros that will teach
how to do several different things, like implementing the pileup weights.
If you add your subdirectory, you should add also a README.md explaining what is in the 
subdirectory and how to use it.
