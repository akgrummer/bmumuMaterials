#!/bin/bash

TARGET=/nfs/monet_3/home/campoverde/Presentations/Pileup_Studies/images/

rm -rf $TARGET/plots_pileup_comparison

cp -r plots $TARGET/plots_pileup_comparison
