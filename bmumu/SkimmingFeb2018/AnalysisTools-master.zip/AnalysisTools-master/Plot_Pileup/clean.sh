#!/bin/bash

rm -f *.pyc
rm -f *.root
rm -f *.json
rm -f err/*
rm -f out/*
rm -f Output/*

rm -rf plots
rm -rf pileup_plots
rm -rf histograms

