// File loader.C
#include <vector>
#ifdef __MAKECINT__
#pragma link C++ class vector<vector<int> >+;
#endif
