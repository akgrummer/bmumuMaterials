#!/bin/bash

rm -f *.out
rm -f *.err

