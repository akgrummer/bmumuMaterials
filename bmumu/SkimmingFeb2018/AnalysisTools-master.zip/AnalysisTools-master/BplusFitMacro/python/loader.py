import ROOT

ROOT.gSystem.Load("../lib/libbplus_fit.so")
ROOT.gROOT.ProcessLine('#include "../include/bplusUMLFitNoErr.h"')
