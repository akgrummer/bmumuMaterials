#!/bin/bash

TARGET=/nfs/monet_3/home/campoverde/Presentations/Pileup_Studies/images/

cp -r plots_data $TARGET
cp -r plots_mc   $TARGET
cp -r reweight   $TARGET
