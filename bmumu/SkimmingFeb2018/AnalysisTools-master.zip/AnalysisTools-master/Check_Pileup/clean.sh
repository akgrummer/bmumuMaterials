#!/bin/bash

rm -rf plots_*
