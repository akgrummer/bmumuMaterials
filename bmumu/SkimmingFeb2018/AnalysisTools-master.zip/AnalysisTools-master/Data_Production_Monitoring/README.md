#### Description

The scripts in this directory are used to monitor the production of Data DxAODs
(for MC the taks is far easier and you should not need any script). You should start
looking at **DxAOD/** and the REAMDE.md there. Afterwards the scripts in **Ntuples/**
will become relevant.
