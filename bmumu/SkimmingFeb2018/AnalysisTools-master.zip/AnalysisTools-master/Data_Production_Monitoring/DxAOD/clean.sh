rm -rf samples_status/*
rm -f read_tasks.log
rm -rf datasets/*
