#!/bin/bash

rm -rf job_status
