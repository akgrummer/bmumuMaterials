#!/bin/bash

#python steer_skim_slurm.py Bmumu     300203 
#python steer_skim_slurm.py BJpsiK    300203
#python steer_skim_slurm.py BsJpsiPhi 300203 
#
#python steer_skim_slurm.py Bmumu     300306
#python steer_skim_slurm.py BJpsiK    300306
#python steer_skim_slurm.py BsJpsiPhi 300306
#
#python steer_skim_slurm.py Bmumu     300307
#python steer_skim_slurm.py BJpsiK    300307
#python steer_skim_slurm.py BsJpsiPhi 300307 
#
#python steer_skim_slurm.py BsJpsiPhi 300438

python steer_skim_slurm.py BJpsiK    300404
#python steer_skim_slurm.py BJpsiK    300405
#
#python steer_skim_slurm.py BJpsiK    300406
#python steer_skim_slurm.py BJpsiPi   300406
#
#python steer_skim_slurm.py BJpsiK    300437
#python steer_skim_slurm.py BJpsiPi   300437
#
#python steer_skim_slurm.py Bmumu     300426
#python steer_skim_slurm.py Bmumu     300430
#-------------------------------------------
#-------------------------------------------
#python steer_skim_slurm.py test 1000 BJpsiK    300404
#python steer_skim_slurm.py test 1000 BJpsiK    300405 
#python steer_skim_slurm.py test 1000 Bmumu     300426 
#python steer_skim_slurm.py test 1000 Bmumu     300430 
#
#python steer_skim_slurm.py test 1000 Bmumu     300203 
#python steer_skim_slurm.py test 1000 BJpsiK    300203
#python steer_skim_slurm.py test 1000 BsJpsiPhi 300203 
#
#python steer_skim_slurm.py test 1000 Bmumu     300306
#python steer_skim_slurm.py test 1000 BJpsiK    300306
#python steer_skim_slurm.py test 1000 BsJpsiPhi 300306
#
#python steer_skim_slurm.py test 1000 Bmumu     300307
#python steer_skim_slurm.py test 1000 BJpsiK    300307
#python steer_skim_slurm.py test 1000 BsJpsiPhi 300307 
#
#python steer_skim_slurm.py test 1000 BsJpsiPhi 300438
#
#python steer_skim_slurm.py test 1000 BJpsiK    300404
#python steer_skim_slurm.py test 1000 BJpsiK    300405
#
#python steer_skim_slurm.py test 1000 BJpsiK    300406
#python steer_skim_slurm.py test 1000 BJpsiPi   300406
#
#python steer_skim_slurm.py test 1000 BJpsiK    300437
#python steer_skim_slurm.py test 1000 BJpsiPi   300437
#
#python steer_skim_slurm.py test 1000 Bmumu     300426
#python steer_skim_slurm.py test 1000 Bmumu     300430
#-------------------------------------------
#-------------------------------------------

