#### What is in this project?

This project contains many directories which contain mostly scripts. They are
used to automatize small tasks. They also document how we got Lumifiles, PRW
files, etc.

Validation code is also placed in among these scripts. Each directory contains
a README.md with instructions on what it is and how to use it.
