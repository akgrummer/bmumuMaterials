#include <string>
#include <vector>
#include <map>

std::map<std::string, int         >  i_1;
std::map<std::string, float       >  i_2;
std::map<std::string, double      >  i_3;
std::map<std::string, bool        >  i_4;
std::map<std::string, std::string >  i_5;

std::map<std::string, std::vector<int> >         iv_1;
std::map<std::string, std::vector<float> >       iv_2;
std::map<std::string, std::vector<double> >      iv_3;
std::map<std::string, std::vector<bool> >        iv_4;
std::map<std::string, std::vector<std::string> > iv_5;

