#!/bin/bash

python mcrw_data.py xaod
python mcrw_data.py xaod_same_trigger
python mcrw_data.py xaod_2015
python mcrw_data.py xaod_2016

#python mcrw_data.py dxaod
#python mcrw_data.py dxaod_2015
#python mcrw_data.py dxaod_2016
