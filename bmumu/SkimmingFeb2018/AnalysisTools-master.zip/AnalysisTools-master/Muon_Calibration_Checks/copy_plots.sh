#!/bin/bash

TARGET=/nfs/monet_3/home/campoverde/Presentations/Beampspot_Reweighting/images/

cp -r /nfs/monet_3/home/campoverde/Scripts/Short_Studies/Muon_Calibration_Checks/Plots $TARGET
cp -r /nfs/monet_3/home/campoverde/Scripts/Short_Studies/Muon_Calibration_Checks/kinematics $TARGET
